﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using BankAccount;

namespace BankAccountTest
{
    class BankAccountCreditTests
    {
        [Test]

        public void TestCreditsWithValidAmount()
        {
            //Arrange
            double beginingBalance = 11.99;
            double creditAmount = 5;
            double expected = beginingBalance + creditAmount;

            BankAccount.BankAccount account =
                new BankAccount.BankAccount("Mr. Proper", beginingBalance);

            //Act

            account.Credit(creditAmount);
            //Assert

            double actual = account.Balance;
            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }


        [Test]
        public void TestCreditWithNegativAmount()
        {
            //Arrange
            double beginingBalance = 11.59;
            double creditAmount = -5.00;

            BankAccount.BankAccount account =
                new BankAccount.BankAccount("Mr. Proper", beginingBalance);

            //Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(()
                => account.Credit(creditAmount));
        }
    }
}
