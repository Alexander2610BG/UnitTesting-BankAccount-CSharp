using NUnit.Framework;
using BankAccount;
using System;

namespace BankAccountTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Debit_WithValidAmount_UpdatesBalance()
        {
            //Arrange
            double beginingBalance = 11.99;
            double debitAmount = 4.55;
            double expected = 7.44;
            BankAccount.BankAccount account = 
                new BankAccount.BankAccount("Mr. Proper", beginingBalance);
            //Act

            account.Debit(debitAmount);
            //Assert

            double actual = account.Balance;
            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }

        [Test]
        public void TestDebitWithInvalidAmount()
        {
            //Arrange
            double beginingBalance = 11.59;
            double debitAmount = 15.00;

            BankAccount.BankAccount account =
                new BankAccount.BankAccount("Mr. Proper", beginingBalance);

            //Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(() 
                => account.Debit(debitAmount));
        }

        [Test]
        public void TestDebitWithNegativAmount()
        {
            //Arrange
            double beginingBalance = 11.59;
            double debitAmount = -5.00;

            BankAccount.BankAccount account =
                new BankAccount.BankAccount("Mr. Proper", beginingBalance);

            //Act & Assert
            Assert.Throws<ArgumentOutOfRangeException>(()
                => account.Debit(debitAmount));
        }
    }
}